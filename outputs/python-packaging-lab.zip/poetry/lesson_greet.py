from rich import print


def main():
    print("[bold green]Hello, Python![/bold green]")
